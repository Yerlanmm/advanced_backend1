package main

import (
	"bufio"
	"fmt"
	"os"
	"strings"

	"./Library"
)

func main() {
	library := Library.NewLibrary()
	scanner := bufio.NewScanner(os.Stdin)

	for {
		fmt.Println("\nChoose an option:")
		fmt.Println("1. Add")
		fmt.Println("2. Borrow")
		fmt.Println("3. Return")
		fmt.Println("4. List")
		fmt.Println("5. Exit")
		fmt.Print("Enter choice: ")

		scanner.Scan()
		choice := strings.TrimSpace(scanner.Text())

		switch choice {
		case "1":
			fmt.Print("Enter Book ID: ")
			scanner.Scan()
			id := strings.TrimSpace(scanner.Text())

			fmt.Print("Enter Book Title: ")
			scanner.Scan()
			title := strings.TrimSpace(scanner.Text())

			fmt.Print("Enter Book Author: ")
			scanner.Scan()
			author := strings.TrimSpace(scanner.Text())

			book := Library.Book{ID: id, Title: title, Author: author, IsBorrowed: false}
			library.AddBook(book)
			fmt.Println("Book added successfully!")

		case "2":
			fmt.Print("Enter Book ID to Borrow: ")
			scanner.Scan()
			id := strings.TrimSpace(scanner.Text())
			err := library.BorrowBook(id)
			if err != nil {
				fmt.Println("Error:", err)
			} else {
				fmt.Println("Book borrowed successfully!")
			}

		case "3":
			fmt.Print("Enter Book ID to Return: ")
			scanner.Scan()
			id := strings.TrimSpace(scanner.Text())
			err := library.ReturnBook(id)
			if err != nil {
				fmt.Println("Error:", err)
			} else {
				fmt.Println("Book returned successfully!")
			}

		case "4":
			library.ListBooks()

		case "5":
			fmt.Println("Exiting program...")
			return

		default:
			fmt.Println("Invalid choice. Please try again.")
		}
	}
}
