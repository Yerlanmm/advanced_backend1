package Library

import (
	"errors"
	"fmt"
)

type Book struct {
	ID         string
	Title      string
	Author     string
	IsBorrowed bool
}

type Library struct {
	collection map[string]Book
}

func NewLibrary() *Library {
	return &Library{collection: make(map[string]Book)}
}

func (lib *Library) AddBook(book Book) {
	lib.collection[book.ID] = book
}

func (lib *Library) BorrowBook(id string) error {
	book, exists := lib.collection[id]
	if !exists {
		return errors.New("book not found")
	}
	if book.IsBorrowed {
		return errors.New("book is already borrowed")
	}
	book.IsBorrowed = true
	lib.collection[id] = book
	return nil
}

func (lib *Library) ReturnBook(id string) error {
	book, exists := lib.collection[id]
	if !exists {
		return errors.New("book not found")
	}
	if !book.IsBorrowed {
		return errors.New("book is not borrowed")
	}
	book.IsBorrowed = false
	lib.collection[id] = book
	return nil
}

func (lib *Library) ListBooks() {
	fmt.Println("Available books:")
	for _, book := range lib.collection {
		if !book.IsBorrowed {
			fmt.Printf("ID: %s, Title: %s, Author: %s\n", book.ID, book.Title, book.Author)
		}
	}
}
