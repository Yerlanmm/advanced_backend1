package main

import (
	"./employees"
	"fmt"
)

func main() {
	company := employees.NewCompany()

	for {
		fmt.Println("\nChoose an option:")
		fmt.Println("1. Add Full-Time Employee")
		fmt.Println("2. Add Part-Time Employee")
		fmt.Println("3. List Employees")
		fmt.Println("4. Exit")
		fmt.Print("Enter choice: ")

		var choice int
		fmt.Scan(&choice)

		switch choice {
		case 1:
			var id uint64
			var name string
			var salary uint32

			fmt.Print("Enter Full-Time Employee ID: ")
			fmt.Scan(&id)
			fmt.Print("Enter Full-Time Employee Name: ")
			fmt.Scan(&name)
			fmt.Print("Enter Salary (in Tenge): ")
			fmt.Scan(&salary)

			emp := employees.FullTimeEmployee{ID: id, Name: name, Salary: salary}
			company.AddEmployee(emp, fmt.Sprintf("%d", id))

		case 2:
			var id uint64
			var name string
			var hourlyRate uint64
			var hoursWorked float32

			fmt.Print("Enter Part-Time Employee ID: ")
			fmt.Scan(&id)
			fmt.Print("Enter Part-Time Employee Name: ")
			fmt.Scan(&name)
			fmt.Print("Enter Hourly Rate (in Tenge): ")
			fmt.Scan(&hourlyRate)
			fmt.Print("Enter Hours Worked: ")
			fmt.Scan(&hoursWorked)

			emp := employees.PartTimeEmployee{ID: id, Name: name, HourlyRate: hourlyRate, HoursWorked: hoursWorked}
			company.AddEmployee(emp, fmt.Sprintf("%d", id))

		case 3:
			company.ListEmployees()

		case 4:
			fmt.Println("Exiting program...")
			return

		default:
			fmt.Println("Invalid choice. Please try again.")
		}
	}
}
