package employees

import "fmt"


type Employee interface {
	GetDetails() string
}


type Company struct {
	employees map[string]Employee
}

func NewCompany() *Company {
	return &Company{employees: make(map[string]Employee)}
}

func (c *Company) AddEmployee(emp Employee, id string) {
	c.employees[id] = emp
	fmt.Println("Employee added successfully!")
}

func (c *Company) ListEmployees() {
	if len(c.employees) == 0 {
		fmt.Println("No employees to display.")
		return
	}
	for id, emp := range c.employees {
		fmt.Printf("Employee ID: %s\n%s\n\n", id, emp.GetDetails())
	}
}
