package employees

import "fmt"


type FullTimeEmployee struct {
	ID     uint64
	Name   string
	Salary uint32
}

func (fte FullTimeEmployee) GetDetails() string {
	return fmt.Sprintf("FullTimeEmployee: ID: %d, Name: %s, Salary: %d Tenge", fte.ID, fte.Name, fte.Salary)
}
