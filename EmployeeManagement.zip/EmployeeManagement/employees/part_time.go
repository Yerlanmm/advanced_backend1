package employees

import "fmt"


type PartTimeEmployee struct {
	ID          uint64
	Name        string
	HourlyRate  uint64
	HoursWorked float32
}

func (pte PartTimeEmployee) GetDetails() string {
	totalEarnings := float64(pte.HourlyRate) * float64(pte.HoursWorked)
	return fmt.Sprintf("PartTimeEmployee: ID: %d, Name: %s, Hourly Rate: %d Tenge, Hours Worked: %.2f, Total Earnings: %.2f Tenge",
		pte.ID, pte.Name, pte.HourlyRate, pte.HoursWorked, totalEarnings)
}
