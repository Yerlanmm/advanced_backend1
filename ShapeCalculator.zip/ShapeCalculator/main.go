package main

import (
	"fmt"
	"./Shapes"
)

func main() {
	shapes := []Shapes.Shape{
		Shapes.Rectangle{Length: 10, Width: 5},
		Shapes.Circle{Radius: 7},
		Shapes.Square{Length: 4},
		Shapes.Triangle{SideA: 3, SideB: 4, SideC: 5},
	}

	for i, shape := range shapes {
		fmt.Printf("Shape %d:\n", i+1)
		Shapes.PrintShapeDetails(shape)
		fmt.Println()
	}
}
