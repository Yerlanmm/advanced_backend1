package main

import (
	"./account"
	"fmt"
)

func main() {
	var accountNumber, holderName string
	var initialBalance float64

	fmt.Println("Create a new bank account:")
	fmt.Print("Enter Account Number: ")
	fmt.Scan(&accountNumber)
	fmt.Print("Enter Holder Name: ")
	fmt.Scan(&holderName)
	fmt.Print("Enter Initial Balance: ")
	fmt.Scan(&initialBalance)

	bankAccount := account.NewBankAccount(accountNumber, holderName, initialBalance)

	for {
		fmt.Println("\nChoose an option:")
		fmt.Println("1. Deposit")
		fmt.Println("2. Withdraw")
		fmt.Println("3. Get Balance")
		fmt.Println("4. Exit")
		fmt.Print("Enter choice: ")

		var choice int
		fmt.Scan(&choice)

		switch choice {
		case 1:
			fmt.Print("Enter amount to deposit: ")
			var amount float64
			fmt.Scan(&amount)
			bankAccount.Deposit(amount)

		case 2:
			fmt.Print("Enter amount to withdraw: ")
			var amount float64
			fmt.Scan(&amount)
			err := bankAccount.Withdraw(amount)
			if err != nil {
				fmt.Println("Error:", err)
			}

		case 3:
			bankAccount.GetBalance()

		case 4:
			fmt.Println("Exiting program...")
			return

		default:
			fmt.Println("Invalid choice. Please try again.")
		}
	}
}
