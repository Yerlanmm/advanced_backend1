package account

import (
	"errors"
	"fmt"
)


type BankAccount struct {
	AccountNumber string
	HolderName    string
	Balance       float64
}


func NewBankAccount(accountNumber, holderName string, initialBalance float64) *BankAccount {
	return &BankAccount{
		AccountNumber: accountNumber,
		HolderName:    holderName,
		Balance:       initialBalance,
	}
}


func (b *BankAccount) Deposit(amount float64) {
	if amount > 0 {
		b.Balance += amount
		fmt.Printf("Deposited %.2f successfully. New balance: %.2f\n", amount, b.Balance)
	} else {
		fmt.Println("Deposit amount must be positive.")
	}
}


func (b *BankAccount) Withdraw(amount float64) error {
	if amount <= 0 {
		return errors.New("withdrawal amount must be positive")
	}
	if b.Balance >= amount {
		b.Balance -= amount
		fmt.Printf("Withdrew %.2f successfully. New balance: %.2f\n", amount, b.Balance)
		return nil
	}
	return errors.New("insufficient balance")
}


func (b *BankAccount) GetBalance() {
	fmt.Printf("Current balance: %.2f\n", b.Balance)
}
