package account

import "fmt"


func Transaction(account *BankAccount, transactions []float64) {
	for _, amount := range transactions {
		if amount > 0 {
			account.Deposit(amount)
		} else {
			err := account.Withdraw(-amount)
			if err != nil {
				fmt.Println("Transaction error:", err)
			}
		}
	}
}
